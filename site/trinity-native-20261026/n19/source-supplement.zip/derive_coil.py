"""Recreate the physical n19 Beacon coil PCB from its public source solid."""
# SPDX-License-Identifier: GPL-3.0-or-later
import argparse
import hashlib
from OCP.BRep import BRep_Builder
from OCP.BRepTools import BRepTools
from OCP.TopoDS import TopoDS_Shape
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from OCP.BRepAlgoAPI import BRepAlgoAPI_Common
from OCP.BRepCheck import BRepCheck_Analyzer
from OCP.TopTools import TopTools_ListOfShape
from OCP.gp import gp_Pnt

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('source_coil_brep')
parser.add_argument('output_coil_brep')
args = parser.parse_args()
with open(args.source_coil_brep, 'rb') as stream:
    assert hashlib.file_digest(stream, 'sha256').hexdigest() == 'adec8147a2b4a159e42926d771563afd260509abcf92c8e44b94f2ea769a84da'
shape = TopoDS_Shape()
assert BRepTools.Read_s(shape, args.source_coil_brep, BRep_Builder())
assert BRepCheck_Analyzer(shape).IsValid()
# Exact source PCB faces5/6. The source cone and spacing disc are CAD helpers.
lower, upper = -78.4, -76.7805976
slab = BRepPrimAPI_MakeBox(gp_Pnt(-50, lower, -20), 100, upper-lower, 100).Shape()
source, tools = TopTools_ListOfShape(), TopTools_ListOfShape()
source.Append(shape)
tools.Append(slab)
operation = BRepAlgoAPI_Common()
operation.SetArguments(source)
operation.SetTools(tools)
operation.SetRunParallel(False)
operation.Build()
assert operation.IsDone()
result = operation.Shape()
assert BRepCheck_Analyzer(result).IsValid()
assert BRepTools.Write_s(result, args.output_coil_brep)
